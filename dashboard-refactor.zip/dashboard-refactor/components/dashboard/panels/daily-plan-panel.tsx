// components/dashboard/panels/daily-plan-panel.tsx
"use client"

import { CalendarClock } from "lucide-react"
import { PanelWrapper } from "./panel-wrapper"

interface DailyPlanPanelProps {
  loading: boolean
  panelColor: string
}

export function DailyPlanPanel({ loading, panelColor }: DailyPlanPanelProps) {
  return (
    <PanelWrapper
      title="每日行程"
      icon={CalendarClock}
      panelColor={panelColor}
      loading={loading}
    >
      <div className="text-center py-6">
        <p className="text-gray-500 mb-2">🚧 功能開發中</p>
        <p className="text-sm text-gray-400">依時間規劃當日行程，敬請期待！</p>
      </div>
    </PanelWrapper>
  )
}
