# Dashboard 重構 - 安裝說明

## 文件結構

請按照以下結構放置文件：

```
你的專案/
├── lib/
│   └── hooks/
│       └── use-dashboard-data.ts        ← 新增
│
├── components/
│   ├── calendar/
│   │   └── calendar-view.tsx            ← 替換（新增 journal_travel, daily_plan）
│   │
│   └── dashboard/                       ← 新增整個資料夾
│       ├── photo-uploader.tsx
│       ├── module-buttons.tsx
│       ├── panels/
│       │   ├── constants.ts
│       │   ├── panel-wrapper.tsx
│       │   ├── schedule-panel.tsx
│       │   ├── task-panel.tsx
│       │   ├── habit-panel.tsx
│       │   ├── journal-life-panel.tsx
│       │   ├── journal-learning-panel.tsx
│       │   ├── journal-reading-panel.tsx
│       │   ├── journal-gratitude-panel.tsx
│       │   ├── journal-travel-panel.tsx
│       │   ├── finance-panel.tsx
│       │   ├── exercise-panel.tsx
│       │   ├── health-panel.tsx
│       │   ├── daily-plan-panel.tsx
│       │   └── index.ts
│       └── dialogs/
│           ├── task-dialog.tsx
│           ├── journal-life-dialog.tsx
│           ├── journal-learning-dialog.tsx
│           ├── journal-reading-dialog.tsx
│           ├── journal-gratitude-dialog.tsx
│           ├── journal-travel-dialog.tsx
│           ├── finance-dialog.tsx
│           ├── exercise-dialog.tsx
│           ├── health-dialog.tsx
│           └── index.ts
│
├── app/
│   └── (dashboard)/
│       └── dashboard/
│           └── page.tsx                 ← 替換
│
└── types/
    └── custom.ts                        ← 替換（新增 JournalTravel 類型）
```

## 安裝步驟

1. **建立資料夾結構**
   ```bash
   mkdir -p lib/hooks
   mkdir -p components/dashboard/panels
   mkdir -p components/dashboard/dialogs
   ```

2. **複製文件**
   - 將下載的文件按上述結構放置

3. **資料庫設置**（如果尚未執行）
   
   在 Supabase 執行 SQL：
   ```sql
   -- 遊覽日誌表
   CREATE TABLE journals_travel (
     id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
     date DATE NOT NULL,
     title TEXT NOT NULL,
     location TEXT NOT NULL,
     duration_minutes INTEGER,
     content TEXT,
     mood INTEGER CHECK (mood >= 1 AND mood <= 5),
     weather TEXT,
     companions TEXT,
     rating INTEGER CHECK (rating >= 1 AND rating <= 5),
     photos TEXT[] DEFAULT '{}',
     created_at TIMESTAMPTZ DEFAULT NOW(),
     updated_at TIMESTAMPTZ DEFAULT NOW()
   );

   CREATE INDEX idx_journals_travel_user_date ON journals_travel(user_id, date);

   ALTER TABLE journals_travel ENABLE ROW LEVEL SECURITY;

   CREATE POLICY "Users can manage own travel journals"
     ON journals_travel FOR ALL
     USING (auth.uid() = user_id)
     WITH CHECK (auth.uid() = user_id);
   ```

4. **Storage Bucket**（如果尚未建立）
   - Bucket 名稱: `travel-photos`
   - Public: 開啟
   - 建立適當的 RLS policies

## 新功能

- ✅ 遊覽日誌（含照片上傳，最多 3 張）
- ✅ 每日行程（預留，功能開發中）
- ✅ 響應式模組按鈕網格（3/4/6 欄）
- ✅ 模組化架構，易於維護和擴展

## 文件說明

| 文件 | 說明 |
|------|------|
| `use-dashboard-data.ts` | 資料獲取 Hook，集中管理所有模組資料 |
| `photo-uploader.tsx` | 可重用的照片上傳元件 |
| `module-buttons.tsx` | 模組按鈕網格和配置 |
| `panels/*.tsx` | 各模組的展開面板 |
| `dialogs/*.tsx` | 各模組的編輯對話框 |
